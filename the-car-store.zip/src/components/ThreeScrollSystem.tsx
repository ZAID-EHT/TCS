import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';

gsap.registerPlugin(ScrollTrigger);

// Helper to generate a stylized metallic low-poly solid model
const createWireframeFallback = (type: 'gtr' | 'lc' | 'defender') => {
  const group = new THREE.Group();
  
  // Premium metallic paint material
  const bodyMat = new THREE.MeshPhysicalMaterial({
    color: 0xe0e0e0,
    metalness: 0.6,
    roughness: 0.2,
    clearcoat: 1.0,
    clearcoatRoughness: 0.1,
  });

  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x111111,
    metalness: 0.9,
    roughness: 0.1,
    transmission: 0.2,
    transparent: true,
  });

  const accentMat = new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0x440000 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.9, roughness: 0.2 });

  const addWheel = (x: number, y: number, z: number, scale: number = 1) => {
    const wheelGroup = new THREE.Group();
    // Tire
    const tireGeo = new THREE.CylinderGeometry(0.4 * scale, 0.4 * scale, 0.25 * scale, 24);
    tireGeo.rotateX(Math.PI / 2);
    const tire = new THREE.Mesh(tireGeo, wheelMat);
    wheelGroup.add(tire);
    // Rim
    const rimGeo = new THREE.CylinderGeometry(0.25 * scale, 0.25 * scale, 0.27 * scale, 12);
    rimGeo.rotateX(Math.PI / 2);
    const rim = new THREE.Mesh(rimGeo, rimMat);
    wheelGroup.add(rim);
    
    wheelGroup.position.set(x, y, z);
    group.add(wheelGroup);
  };

  if (type === 'gtr') {
    // Sleek Sports Car
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.6, 1.9), bodyMat);
    chassis.position.y = 0.4;
    group.add(chassis);

    const cabin = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.5, 1.5), glassMat);
    cabin.position.set(-0.2, 0.95, 0);
    group.add(cabin);

    const spoilerL = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.3, 0.1), bodyMat);
    spoilerL.position.set(1.9, 0.85, 0.6);
    group.add(spoilerL);
    
    const spoilerR = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.3, 0.1), bodyMat);
    spoilerR.position.set(1.9, 0.85, -0.6);
    group.add(spoilerR);

    const spoilerWing = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.05, 1.6), bodyMat);
    spoilerWing.position.set(1.9, 1.0, 0);
    group.add(spoilerWing);
    
    // Tail lights
    const tailLight1 = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.1, 16), accentMat);
    tailLight1.rotateZ(Math.PI/2);
    tailLight1.position.set(2.2, 0.5, 0.5);
    group.add(tailLight1);
    const tailLight2 = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.1, 16), accentMat);
    tailLight2.rotateZ(Math.PI/2);
    tailLight2.position.set(2.2, 0.5, -0.5);
    group.add(tailLight2);

    addWheel(-1.3, 0.4, 1.0);
    addWheel(1.4, 0.4, 1.0);
    addWheel(-1.3, 0.4, -1.0);
    addWheel(1.4, 0.4, -1.0);
    
    group.scale.set(1.1, 1.1, 1.1);
  } else if (type === 'lc') {
    // Large SUV
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(4.8, 1.0, 2.0), bodyMat);
    chassis.position.y = 0.7;
    group.add(chassis);

    const cabin = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.8, 1.8), glassMat);
    cabin.position.set(0.2, 1.6, 0);
    group.add(cabin);

    const grille = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.6, 1.2), rimMat);
    grille.position.set(-2.4, 0.8, 0);
    group.add(grille);

    addWheel(-1.6, 0.45, 1.05, 1.1);
    addWheel(1.5, 0.45, 1.05, 1.1);
    addWheel(-1.6, 0.45, -1.05, 1.1);
    addWheel(1.5, 0.45, -1.05, 1.1);
    
    group.scale.set(1.0, 1.0, 1.0);
  } else if (type === 'defender') {
    // Boxy Off-Roader
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(4.5, 1.1, 2.1), bodyMat);
    chassis.position.y = 0.85;
    group.add(chassis);

    const cabin = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.95, 1.9), glassMat);
    cabin.position.set(0.5, 1.9, 0);
    group.add(cabin);

    const spareTireGroup = new THREE.Group();
    const spareTire = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.25, 24), wheelMat);
    spareTire.rotateZ(Math.PI / 2);
    const spareRim = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.27, 12), rimMat);
    spareRim.rotateZ(Math.PI / 2);
    spareTireGroup.add(spareTire);
    spareTireGroup.add(spareRim);
    spareTireGroup.position.set(2.35, 1.4, 0);
    group.add(spareTireGroup);

    const roofRack = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.1, 1.8), wheelMat);
    roofRack.position.set(0.5, 2.45, 0);
    group.add(roofRack);

    addWheel(-1.4, 0.5, 1.1, 1.25);
    addWheel(1.5, 0.5, 1.1, 1.25);
    addWheel(-1.4, 0.5, -1.1, 1.25);
    addWheel(1.5, 0.5, -1.1, 1.25);
    
    group.scale.set(0.95, 0.95, 0.95);
  }
  
  return group;
};

// Async model loading function
const loadModel = (url: string, type: 'gtr' | 'lc' | 'defender'): Promise<THREE.Group> => {
  return new Promise((resolve) => {
    const loader = new GLTFLoader();
    loader.load(
      url,
      (gltf) => {
        // Adjust the loaded model
        const model = gltf.scene;
        // Optionally traverse and apply specific materials
        model.traverse((child: any) => {
          if (child.isMesh) {
            child.material.envMapIntensity = 1.5; // Ensure good lighting reaction
          }
        });
        const group = new THREE.Group();
        group.add(model);
        resolve(group);
      },
      undefined,
      // On Error -> Use the solid fallback model
      () => {
        console.warn(`Could not load ${url}. Falling back to stylized 3D representation.`);
        resolve(createWireframeFallback(type));
      }
    );
  });
};

export const ThreeScrollSystem = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const carsGroupRef = useRef<THREE.Group>(new THREE.Group());
  
  useEffect(() => {
    // Initialize Lenis for smooth scroll
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      gsap.ticker.remove(lenis.raf);
    };
  }, []);

  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;

    // Three.js SCENE INIT
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#ffffff');
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 2, 10);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;

    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);
    
    const dirLight = new THREE.DirectionalLight(0xffffff, 3);
    dirLight.position.set(5, 10, 7);
    dirLight.castShadow = true;
    scene.add(dirLight);
    
    const dirLight2 = new THREE.DirectionalLight(0xddeeff, 2);
    dirLight2.position.set(-5, 5, -5);
    scene.add(dirLight2);

    const carsGroup = new THREE.Group();
    carsGroup.position.x = -2.5; // Move left
    scene.add(carsGroup);
    carsGroupRef.current = carsGroup;

    // Grid helper for tech aesthetic
    const gridHelper = new THREE.GridHelper(20, 20, 0x000000, 0x000000);
    gridHelper.material.opacity = 0.05;
    gridHelper.material.transparent = true;
    gridHelper.position.y = -0.5;
    scene.add(gridHelper);

    // Initial positioning
    carsGroup.rotation.y = -Math.PI / 4 + 0.5;
    carsGroup.rotation.x = 0.15;

    // Load actual GLTF models or fallbacks asynchronously
    Promise.all([
      loadModel('/models/gtr.glb', 'gtr'),
      loadModel('/models/landcruiser.glb', 'lc'),
      loadModel('/models/defender.glb', 'defender')
    ]).then(([gtr, lc, defender]) => {
      
      gtr.position.set(0, 0, 0); // Active first
      lc.position.set(0, -20, 0); // Hidden
      defender.position.set(0, -20, 0); // Hidden

      carsGroup.add(gtr);
      carsGroup.add(lc);
      carsGroup.add(defender);

      // GSAP SCROLLTRIGGER TIMELINE - Requires models to be loaded
      const ctx = gsap.context(() => {
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top top",
            end: "+=3000",
            scrub: 1.5,
            pin: true,
            onUpdate: (self) => {
              // Manage model visibility manually based on progress for performance
              const p = self.progress;
              if(p < 0.33) {
                gtr.position.y = 0;
                lc.position.y = -20;
                defender.position.y = -20;
              } else if (p >= 0.33 && p < 0.66) {
                gtr.position.y = -20;
                lc.position.y = 0;
                defender.position.y = -20;
              } else {
                gtr.position.y = -20;
                lc.position.y = -20;
                defender.position.y = 0;
              }
            }
          }
        });

        // Part 1: GTR Rotation (0% - 33%)
        tl.to(carsGroup.rotation, { y: Math.PI / 2, ease: "none" }, 0);
        tl.to(gtr.scale, { x: 1.2, y: 1.2, z: 1.2, ease: "power1.inOut" }, 0);
        tl.to("#slide_gtr", { opacity: 0, scale: 0.95 }, 0.25);
        tl.to(".gtr-tooltip", { opacity: 0, x: -20, stagger: 0.05 }, 0.20);
        tl.to("#reveal_circle", { scale: 0, autoAlpha: 0, duration: 0.1 }, 0.3);

        // Part 2: LC Transition and Rotation (33% - 66%)
        tl.to("#reveal_circle", { scale: 100, autoAlpha: 1, duration: 0.8, ease: "power3.inOut" }, 0.31);
        tl.fromTo("#slide_lc", { opacity: 0, y: 50 }, { opacity: 1, y: 0 }, 0.33);
        tl.fromTo(".lc-tooltip", { opacity: 0, x: 20 }, { opacity: 1, x: 0, stagger: 0.05 }, 0.35);
        tl.to(carsGroup.rotation, { y: Math.PI * 1.5, ease: "none" }, 0.33);
        tl.fromTo(lc.scale, { x: 0.8, y: 0.8, z: 0.8 }, { x: 1.1, y: 1.1, z: 1.1, ease: "power1.inOut" }, 0.33);
        tl.to("#slide_lc", { opacity: 0, scale: 0.95 }, 0.60);
        tl.to(".lc-tooltip", { opacity: 0, x: 20, stagger: 0.05 }, 0.55);
        tl.to("#reveal_circle", { scale: 0, autoAlpha: 0, duration: 0.1 }, 0.64);

        // Part 3: Defender Transition and Rotation (66% - 100%)
        tl.to("#reveal_circle", { scale: 100, autoAlpha: 1, duration: 0.8, ease: "power3.inOut" }, 0.65);
        tl.fromTo("#slide_defender", { opacity: 0, y: 50 }, { opacity: 1, y: 0 }, 0.66);
        tl.fromTo(".def-tooltip", { opacity: 0, x: -20 }, { opacity: 1, x: 0, stagger: 0.05 }, 0.68);
        tl.to(carsGroup.rotation, { y: Math.PI * 2.5, ease: "none" }, 0.66);
        tl.fromTo(defender.scale, { x: 0.8, y: 0.8, z: 0.8 }, { x: 1, y: 1, z: 1, ease: "power1.inOut" }, 0.66);
      });
      // Store context so we can revert it on unmount
      (containerRef.current as any)._ctx = ctx;
    });

    // RENDER LOOP
    const render = () => {
      renderer.render(scene, camera);
    };
    gsap.ticker.add(render);

    // HANDLE RESIZE
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      gsap.ticker.remove(render);
      window.removeEventListener('resize', handleResize);
      if ((containerRef.current as any)?._ctx) {
        (containerRef.current as any)._ctx.revert();
      }
      renderer.dispose();
      scene.clear();
    };
  }, []);

  return (
    <section ref={containerRef} className="relative w-full h-[100vh] bg-white overflow-hidden z-20 border-b border-black/10">
      
      {/* Circular Reveal Element */}
      <div 
        id="reveal_circle" 
        className="absolute top-1/2 left-1/2 w-4 h-4 bg-neutral-100 rounded-full pointer-events-none z-0 transform -translate-x-1/2 -translate-y-1/2 opacity-0"
        style={{ transformOrigin: "center center" }}
      />
      
      {/* Absolute 3D Canvas Background */}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 w-full h-full pointer-events-none z-0" 
      />

      {/* Foreground Animated HTML Text Blocks */}
      <div className="absolute inset-0 w-full h-full pointer-events-none z-10 flex items-center justify-start md:justify-center px-6 md:px-0 text-black">
        
        {/* GT-R Content */}
        <div id="slide_gtr" className="w-full max-w-7xl mx-auto absolute">
          <div className="md:w-1/2 md:ml-auto relative bg-white/50 backdrop-blur-md p-8 sm:p-12 rounded-3xl border border-black/5 shadow-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-black/20 rounded-full text-[10px] font-mono tracking-widest uppercase text-black/70 bg-white/50 w-fit mb-6">
              <span className="font-bold text-black">STAGE 01</span> • CORE DRIFT WEAPON
            </div>
            <h2 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black leading-[0.9] mb-6">
              NISSAN GT-R<br />
              <span className="underline decoration-2 underline-offset-4 opacity-50">R35 COUPE</span>
            </h2>
            <div className="grid grid-cols-2 gap-y-6 gap-x-4 pt-6 border-t border-black/10 font-mono text-xs text-black">
              <div className="gtr-tooltip"><span className="text-black/50 block mb-1">ENGINE</span><span className="font-bold text-black">V6 VR38DETT</span></div>
              <div className="gtr-tooltip"><span className="text-black/50 block mb-1">ARMOR</span><span className="font-bold text-black">Self-Healing PPF</span></div>
              <div className="gtr-tooltip"><span className="text-black/50 block mb-1">EXHAUST</span><span className="font-bold text-black">Titanium Quad</span></div>
              <div className="gtr-tooltip"><span className="text-black/50 block mb-1">AERO</span><span className="font-bold text-black">Carbon Splitter</span></div>
            </div>
          </div>
        </div>

        {/* Land Cruiser Content */}
        <div id="slide_lc" className="w-full max-w-7xl mx-auto absolute opacity-0">
          <div className="md:w-1/2 md:ml-auto relative bg-white/50 backdrop-blur-md p-8 sm:p-12 rounded-3xl border border-black/5 shadow-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-black/20 rounded-full text-[10px] font-mono tracking-widest uppercase text-black/70 bg-white/50 w-fit mb-6">
              <span className="font-bold text-black">STAGE 02</span> • SUPREME PRESTIGE
            </div>
            <h2 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black leading-[0.9] mb-6">
              TOYOTA LAND<br />
              <span className="underline decoration-2 underline-offset-4 opacity-50">CRUISER 300</span>
            </h2>
            <div className="grid grid-cols-2 gap-y-6 gap-x-4 pt-6 border-t border-black/10 font-mono text-xs text-black">
              <div className="lc-tooltip"><span className="text-black/50 block mb-1">CABIN</span><span className="font-bold text-black">Ceramic Ext Tints</span></div>
              <div className="lc-tooltip"><span className="text-black/50 block mb-1">PAINT</span><span className="font-bold text-black">9H Quartz Nano</span></div>
              <div className="lc-tooltip"><span className="text-black/50 block mb-1">CHASSIS</span><span className="font-bold text-black">Ladder Frame</span></div>
              <div className="lc-tooltip"><span className="text-black/50 block mb-1">WHEELS</span><span className="font-bold text-black">22" Forged Alloys</span></div>
            </div>
          </div>
        </div>

        {/* Defender Content */}
        <div id="slide_defender" className="w-full max-w-7xl mx-auto absolute opacity-0">
          <div className="md:w-1/2 md:ml-auto relative bg-white/50 backdrop-blur-md p-8 sm:p-12 rounded-3xl border border-black/5 shadow-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-black/20 rounded-full text-[10px] font-mono tracking-widest uppercase text-black/70 bg-white/50 w-fit mb-6">
              <span className="font-bold text-black">STAGE 03</span> • OFF-ROAD ROUGH
            </div>
            <h2 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black leading-[0.9] mb-6">
              LAND ROVER<br />
              <span className="underline decoration-2 underline-offset-4 opacity-50">DEFENDER 110</span>
            </h2>
            <div className="grid grid-cols-2 gap-y-6 gap-x-4 pt-6 border-t border-black/10 font-mono text-xs text-black">
              <div className="def-tooltip"><span className="text-black/50 block mb-1">COATING</span><span className="font-bold text-black">Satin Tough V2</span></div>
              <div className="def-tooltip"><span className="text-black/50 block mb-1">FACELIFT</span><span className="font-bold text-black">Urban LED Grille</span></div>
              <div className="def-tooltip"><span className="text-black/50 block mb-1">UTILITY</span><span className="font-bold text-black">Roof Rack Rail</span></div>
              <div className="def-tooltip"><span className="text-black/50 block mb-1">SUSPENSION</span><span className="font-bold text-black">Air Lift System</span></div>
            </div>
          </div>
        </div>

      </div>

    </section>
  );
};
