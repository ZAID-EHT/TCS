import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Gauge, Cpu, Zap, Compass, Rotate3d, Settings } from 'lucide-react';
import { CarModel } from '../types';

// Let's import the specific images that we generated!
import gtrImage from '../assets/images/gtr_profile_1779687471985.png';
import lcImage from '../assets/images/land_cruiser_profile_1779687487703.png';
import defenderImage from '../assets/images/defender_profile_1779687501759.png';

interface ThreeDCarouselProps {
  onSelectCar: (carId: string) => void;
  activeCarId: string;
}

export const carModelsData: CarModel[] = [
  {
    id: 'gtr',
    name: 'Nissan GT-R R35',
    image: gtrImage,
    year: 'FACELIFT EDITION',
    specs: {
      engine: '3.8L V6 Twin-Turbo VR38DETT',
      power: '565 HP / 633 Nm',
      transmission: '6-Speed Dual-Clutch',
      drivetrain: 'ATTESA E-TS AWD System',
    },
    customizerOptions: {
      basePriceLKR: 38000000,
      ppfCostLKR: 950000,
      wrappingCostLKR: 650000,
      nanoCoatingCostLKR: 180000,
      bodykitCostLKR: 2800000,
      audioCostLKR: 850000,
    },
    description: 'The ultimate Japanese supercar. At The Car Store, we specialize in complete GT-R perfection: structural carbon upgrades, custom titanium exhaust installations, heat rejection tint wrappers, and soundstage-tuned high-end audio setups.',
  },
  {
    id: 'land_cruiser',
    name: 'Toyota Land Cruiser 300',
    image: lcImage,
    year: 'PREMIUM CHASSIS',
    specs: {
      engine: '3.3L Twin-Turbo V6 Diesel',
      power: '304 HP / 700 Nm',
      transmission: '10-Speed Automatic',
      drivetrain: 'Full-Time 4WD with Diff Locks',
    },
    customizerOptions: {
      basePriceLKR: 65000000,
      ppfCostLKR: 1100000,
      wrappingCostLKR: 750000,
      nanoCoatingCostLKR: 220000,
      bodykitCostLKR: 3500000,
      audioCostLKR: 1100000,
    },
    description: 'An icon of absolute prestige and resilience in Sri Lanka. We offer bespoke interior redesigns, armor-grade Paint Protection Film (PPF) for absolute paint security, full chrome-delete stealth black conversions, and flagship audio installations.',
  },
  {
    id: 'defender',
    name: 'Land Rover Defender 110',
    image: defenderImage,
    year: 'ADVENTURE BUILD',
    specs: {
      engine: '3.0L i6 MHEV Ingenium Turbo',
      power: '400 HP / 550 Nm',
      transmission: '8-Speed Automatic',
      drivetrain: 'Configurable Terrain Response AWD',
    },
    customizerOptions: {
      basePriceLKR: 58000000,
      ppfCostLKR: 1200000,
      wrappingCostLKR: 800000,
      nanoCoatingCostLKR: 210000,
      bodykitCostLKR: 3200000,
      audioCostLKR: 950000,
    },
    description: 'Modern rugged intelligence. The Car Store equips local Defenders with high-tech carbon facelifts, matte-finish protective wraps, acoustic cabin dampening, premium door-mounted component subwoofers, and ultra gloss nano quartz coating.',
  },
];

export const ThreeDCarousel: React.FC<ThreeDCarouselProps> = ({ onSelectCar, activeCarId }) => {
  const [currentIndex, setCurrentIndex] = useState(
    carModelsData.findIndex(car => car.id === activeCarId) !== -1 
      ? carModelsData.findIndex(car => car.id === activeCarId) 
      : 0
  );
  const [rotateAngle, setRotateAngle] = useState(0);

  const prevCar = () => {
    const nextIdx = (currentIndex - 1 + carModelsData.length) % carModelsData.length;
    setCurrentIndex(nextIdx);
    setRotateAngle(prev => prev + 120); // 360 / 3 items = 120deg
    onSelectCar(carModelsData[nextIdx].id);
  };

  const nextCar = () => {
    const nextIdx = (currentIndex + 1) % carModelsData.length;
    setCurrentIndex(nextIdx);
    setRotateAngle(prev => prev - 120);
    onSelectCar(carModelsData[nextIdx].id);
  };

  const currentCar = carModelsData[currentIndex];

  return (
    <div id="showroom_deck" className="w-full bg-white relative flex flex-col items-center py-12 md:py-20 overflow-hidden">
      {/* Visual Back-Grid accent */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0.015),transparent_75%)] pointer-events-none" />
      
      {/* Showroom Title header */}
      <div className="text-center mb-10 md:mb-16 px-4 z-10 max-w-2xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 border border-black/10 rounded-full text-[10px] font-mono tracking-widest uppercase text-black/60 mb-3 bg-white shadow-xs">
          <Rotate3d className="w-3.5 h-3.5 text-black hover:rotate-180 transition-transform duration-700" />
          Interactive 3D Showroom Deck
        </div>
        <h2 className="font-display text-3xl md:text-5xl font-black text-black uppercase tracking-tight leading-none">
          CHOOSE YOUR ARCHETYPE
        </h2>
        <p className="font-sans text-xs md:text-sm text-black/60 mt-2 font-light">
          Tap or swipe to rotate the custom blueprints. Scroll down to apply bespoke performance wraps, face lifts, and audio systems.
        </p>
      </div>

      {/* Actual 3D Cylindrical Wrapper */}
      <div className="relative w-full max-w-5xl h-[300px] md:h-[450px] flex items-center justify-center perspective-container px-4">
        {/* Nav Controls */}
        <button
          onClick={prevCar}
          id="btn_prev_car"
          className="absolute left-2 md:left-8 z-30 p-3 bg-white border border-black rounded-full text-black hover:bg-black hover:text-white transition-all cursor-pointer shadow-md"
          aria-label="Previous Vehicle"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={nextCar}
          id="btn_next_car"
          className="absolute right-2 md:right-8 z-30 p-3 bg-white border border-black rounded-full text-black hover:bg-black hover:text-white transition-all cursor-pointer shadow-md"
          aria-label="Next Vehicle"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* 3D Rotate Cylinder */}
        <div 
          className="relative w-full h-[220px] md:h-[350px] transition-transform duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)] preserve-3d"
          style={{ transform: `rotateY(${rotateAngle}deg)` }}
        >
          {carModelsData.map((car, idx) => {
            // Determine position angle for 3 elements: 0, 120, 240
            const angle = idx * 120;
            // Let's pull the cards back by a translation vector
            const translateZValue = 'calc(180px + 10vw)';
            const isSelected = activeCarId === car.id;

            return (
              <div
                key={car.id}
                onClick={() => {
                  if (!isSelected) {
                    const diff = idx - currentIndex;
                    // Find the shortest rotation angle
                    let steps = diff;
                    if (steps > 1) steps -= 3;
                    if (steps < -1) steps += 3;
                    setRotateAngle(prev => prev - steps * 120);
                    setCurrentIndex(idx);
                    onSelectCar(car.id);
                  }
                }}
                className={`absolute inset-y-0 w-[270px] sm:w-[350px] md:w-[480px] h-full left-1/2 -ml-[135px] sm:-ml-[175px] md:-ml-[240px] flex flex-col justify-center items-center bg-white border ${
                  isSelected ? 'border-black shadow-lg bg-white/100' : 'border-black/5 opacity-30 scale-90 select-none bg-white/70'
                } rounded-lg p-3 md:p-6 transition-all duration-700 ease-out cursor-pointer preserve-3d`}
                style={{
                  transform: `rotateY(${angle}deg) translateZ(${translateZValue})`,
                  backfaceVisibility: 'hidden',
                }}
              >
                {/* Car visual model */}
                <div className="relative w-full flex-1 flex items-center justify-center scanline">
                  {/* Subtle shadows under wheels */}
                  <div className="absolute bottom-[20%] w-[80%] h-4 bg-radial-gradient from-black/10 to-transparent filter blur-md pointer-events-none" />
                  
                  <motion.img
                    src={car.image}
                    alt={car.name}
                    id={`active_img_${car.id}`}
                    referrerPolicy="no-referrer"
                    className="max-h-[140px] md:max-h-[220px] w-auto object-contain select-none z-10 filter brightness-[0.98] contrast-[1.05]"
                    initial={{ y: 10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  />
                  
                  {/* Status outline label inside the card */}
                  <div className="absolute top-1 right-2 text-[9px] font-mono tracking-widest text-black/40">
                    {car.year}
                  </div>
                </div>

                {/* Selection and simple brand watermark */}
                <div className="text-center mt-2 z-10">
                  <h3 className="font-display text-lg md:text-2xl font-bold uppercase tracking-tight text-black">
                    {car.name}
                  </h3>
                  <div className="h-[2px] w-12 bg-black mx-auto mt-1" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Detailed Spec overlay panel below carousel */}
      <motion.div
        key={currentCar.id}
        initial={{ y: 25, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -25, opacity: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-4xl px-6 grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mt-12 z-20"
      >
        {/* Narrative */}
        <div className="flex flex-col justify-center">
          <span className="text-[10px] font-mono tracking-widest text-black/50 uppercase">THE VEHICLE APEX</span>
          <h4 className="font-display text-2xl md:text-3xl font-bold tracking-tight text-black uppercase mt-1">
            {currentCar.name}
          </h4>
          <p className="font-sans text-xs md:text-sm text-black/70 leading-relaxed mt-3 font-light">
            {currentCar.description}
          </p>
          <div className="mt-5 flex gap-4">
            <a 
              href="#customizer" 
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-black text-white hover:bg-neutral-800 text-[11px] font-mono tracking-wider uppercase border border-black transition-all font-semibold"
            >
              <Settings className="w-3.5 h-3.5 animate-spin-slow" />
              Configure Upgrades
            </a>
            <a 
              href="#contact" 
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white text-black hover:bg-neutral-50 text-[11px] font-mono tracking-wider uppercase border border-black transition-all"
            >
              Inquire Build
            </a>
          </div>
        </div>

        {/* Technical specs block */}
        <div className="border border-black/10 rounded-lg p-5 md:p-6 bg-neutral-50/50 flex flex-col justify-between">
          <span className="text-[9px] font-mono tracking-widest text-black/40 uppercase mb-4 block">
            CHASSIS METRICS & CONFIG
          </span>
          <div className="space-y-4">
            <div className="flex justify-between items-center border-b border-black/5 pb-2">
              <span className="text-black/50 text-[11px] font-medium flex items-center gap-1.5 font-sans">
                <Cpu className="w-3.5 h-3.5 text-black/40" /> Engine
              </span>
              <span className="text-black font-semibold text-[11px] md:text-xs font-mono text-right">
                {currentCar.specs.engine}
              </span>
            </div>
            <div className="flex justify-between items-center border-b border-black/5 pb-2">
              <span className="text-black/50 text-[11px] font-medium flex items-center gap-1.5 font-sans">
                <Gauge className="w-3.5 h-3.5 text-black/40" /> Output
              </span>
              <span className="text-black font-semibold text-[11px] md:text-xs font-mono text-right">
                {currentCar.specs.power}
              </span>
            </div>
            <div className="flex justify-between items-center border-b border-black/5 pb-2">
              <span className="text-black/50 text-[11px] font-medium flex items-center gap-1.5 font-sans">
                <Zap className="w-3.5 h-3.5 text-black/40" /> Transmission
              </span>
              <span className="text-black font-semibold text-[11px] md:text-xs font-mono text-right">
                {currentCar.specs.transmission}
              </span>
            </div>
            <div className="flex justify-between items-center pb-2">
              <span className="text-black/50 text-[11px] font-medium flex items-center gap-1.5 font-sans">
                <Compass className="w-3.5 h-3.5 text-black/40" /> Drivetrain
              </span>
              <span className="text-black font-semibold text-[11px] md:text-xs font-mono text-right">
                {currentCar.specs.drivetrain}
              </span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
