import React, { useState } from 'react';
import { Shield, Sparkles, Sun, Palette, Wind, Volume2, ArrowUpRight, CheckCircle2, Clock } from 'lucide-react';
import { ServiceDetail } from '../types';

export const servicesData: ServiceDetail[] = [
  {
    id: 'ppf',
    title: 'Paint Protection Film (PPF)',
    shortDescription: 'Self-healing polyurethene armoring against chips, debris, and extreme weathering.',
    fullDescription: 'Our premium self-healing polyurethane films are custom-cut to shield your vehicle’s factory gloss. Offering elite resistance against stone chips, highway gravel scars, scratches, and chemical staining.',
    benefits: ['10-Year self-healing performance', 'High optical clarity without yellowing', 'Hydrophobic dirt-repellent top coat'],
    brands: ['AVERY DENNISON', 'CARBINS', '3M Pro Series'],
    approxTime: '3-4 Days'
  },
  {
    id: 'nano',
    title: 'Nano Ceramic Coating',
    shortDescription: 'Ultimate quartz shield locking in deep, mirrors-like reflectivity and hyper-gloss.',
    fullDescription: 'Unlock a permanent, ultra-high surface hardness (9H+) that repels environmental pollutants. Our professional multi-stage liquid glass application renders routine washing incredibly easy while securing deep color saturation.',
    benefits: ['9H+ Mineral quartz hardness', 'Hyper-beading hydrophobic effect', 'Extreme UV fade immunity'],
    brands: ['Gtechniq', 'CarPro Cquartz', 'Modesta Master'],
    approxTime: '2 Days'
  },
  {
    id: 'tinting',
    title: 'Heat Rejection Window Tint',
    shortDescription: 'Acoustic comfort, high heat blockage, and UV prevention using multi-layered nano-ceramics.',
    fullDescription: 'Defeat hot equatorial sun rays. Our high-tech nano-ceramic films filter up to 99% of harmful infrared heat and UV radiation without interfering with key GPS or network signals.',
    benefits: ['99% Infrared rejection efficiency', 'Total privacy matching OEM shades', 'Skin & leather preservation'],
    brands: ['3M Stable Color', 'Avery Supreme', 'TeckWrap Films'],
    approxTime: '4-6 Hours'
  },
  {
    id: 'bodykits',
    title: 'Carbon Fiber & Facelift Bodykits',
    shortDescription: 'Modern conversion bumpers, spoilers, custom steering wheels, and pristine carbon details.',
    fullDescription: 'Give your vehicle an elite modern makeover. We carry out complete facelift conversions (e.g., retrofitting older models to the newest flagship fascia) and precision installs of spoilers, diffusers, and carbon trim.',
    benefits: ['Flawless bolt-on alignment', 'Pre-impregnated vacuum autoclaved carbon', 'Sleek modern restyling conversions'],
    brands: ['TECKWRAP Line Up', 'OEM Facelifts', 'DryCarbon Bespoke'],
    approxTime: '2-5 Days'
  },
  {
    id: 'detailing',
    title: 'Precision Detailing & Restoration',
    shortDescription: 'Extreme paint correction, leather rejuvenation, and surgical interior sanitization.',
    fullDescription: 'A deep, surgical purification of your vehicle. Utilizing professional polishers to eliminate swirl marks and paint defects, followed by hot steam extraction and delicate leather conditioning for standard new-car freshness.',
    benefits: ['Multi-step rotary paint correction', 'Surgical fine-crack steam cleanse', 'Premium leather hydration & seal'],
    brands: ['Rupes System', 'Chemical Guys', 'Meguiar’s Professional'],
    approxTime: '1-2 Days'
  },
  {
    id: 'audio',
    title: 'High-End Stereo & Audio Systems',
    shortDescription: 'Acoustically sound-dampened cabins paired with flagship speakers and subwoofers.',
    fullDescription: 'Elevate your driving soundstage. We engineer custom audio solutions utilizing advanced multi-channel DSP tuning, premium speaker components, heavy-hitting subwoofers, and full interior sound insulation.',
    benefits: ['Custom high-density soundstage layouts', 'Multi-layer butyl sound insulation', 'Tuned DSP equalization matching car acoustics'],
    brands: ['KENWOOD', 'Pioneer', 'JBL', 'Nakamichi'],
    approxTime: '1 Day'
  }
];

// Helper to pull icons based on ID
const getServiceIcon = (id: string, className: string) => {
  switch (id) {
    case 'ppf': return <Shield className={className} />;
    case 'nano': return <Sparkles className={className} />;
    case 'tinting': return <Sun className={className} />;
    case 'bodykits': return <Palette className={className} />;
    case 'detailing': return <Wind className={className} />;
    case 'audio': return <Volume2 className={className} />;
    default: return <Shield className={className} />;
  }
};

export const ServicesGrid: React.FC = () => {
  const [selectedService, setSelectedService] = useState<ServiceDetail | null>(null);

  return (
    <section id="services_section" className="bg-white text-black py-16 md:py-24 border-y border-black/5 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-16">
          <div className="max-w-xl">
            <span className="text-[10px] font-mono tracking-widest text-black/50 uppercase block mb-1">
              OUR OPERATIONS
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-black text-black uppercase tracking-tight leading-none">
              THE PERFECTION MATRIX
            </h2>
            <p className="font-sans text-xs md:text-sm text-black/60 font-light mt-2">
              From mirror-like nano glass coats to high-performance sound dampening, we execute automotive refinement under surgical conditions.
            </p>
          </div>
          <div className="mt-4 md:mt-0 font-mono text-[11px] text-black/60 border-l-2 border-black pl-3 py-1 bg-neutral-50 rounded-r">
            LOCATED IN DEHIWALA • Sri Lanka<br />
            PREMIUM CUSTOM WORKS
          </div>
        </div>

        {/* Services Squares Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesData.map((service) => (
            <div
              key={service.id}
              onClick={() => setSelectedService(service)}
              id={`service_card_${service.id}`}
              className="group border border-black/10 hover:border-black/100 p-6 flex flex-col justify-between min-h-[220px] transition-all duration-300 bg-white hover:shadow-lg cursor-pointer transform hover:-translate-y-1"
            >
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2 border border-black/5 group-hover:border-black/20 group-hover:bg-neutral-50 transition-colors">
                    {getServiceIcon(service.id, "w-6 h-6 text-black/80")}
                  </div>
                  <span className="text-[10px] font-mono text-black/40 group-hover:text-black mt-2">
                    [ 0{servicesData.indexOf(service) + 1} ]
                  </span>
                </div>
                
                <h3 className="font-display text-lg font-bold uppercase tracking-tight text-black group-hover:underline">
                  {service.title}
                </h3>
                <p className="font-sans text-[11px] md:text-xs text-black/60 font-light mt-2 leading-relaxed h-[60px] line-clamp-3">
                  {service.shortDescription}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-black/5 flex justify-between items-center text-black/50 group-hover:text-black font-mono text-[10px] tracking-wider uppercase">
                <span>Approx: {service.approxTime}</span>
                <span className="flex items-center gap-1">
                  View Detail <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Brand alignment banner (derived directly from attached flyers) */}
        <div className="mt-16 md:mt-24 pt-10 border-t border-black/10 text-center">
          <p className="font-mono text-[9px] text-black/40 tracking-widest uppercase mb-8">
            AUTHORISED STYLING & SOUND INTERMEDIARY BRANDS
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-6 opacity-80 filter saturate-0 hover:opacity-100 transition-opacity">
            <span className="font-display text-base tracking-widest font-extrabold font-mono text-neutral-900">KENWOOD</span>
            <span className="font-display text-base tracking-widest font-extrabold font-mono text-neutral-900">Pioneer</span>
            <span className="font-display text-base tracking-widest font-extrabold font-mono text-neutral-900">Lenovo</span>
            <span className="font-display text-base tracking-widest font-extrabold font-mono text-neutral-900">Nakamichi</span>
            <span className="font-display text-base tracking-widest font-extrabold font-mono text-neutral-900">JBL</span>
            <span className="font-display text-xs tracking-wider font-semibold uppercase text-neutral-900 border border-neutral-700 px-2 py-0.5">AVERY DENNISON</span>
            <span className="font-display text-xs tracking-wider font-semibold uppercase text-neutral-900 border border-neutral-700 px-2 py-0.5">TECKWRAP</span>
            <span className="font-display text-xs tracking-normal font-extrabold font-mono text-neutral-900">3M VINYL</span>
            <span className="font-display text-xs tracking-wider font-semibold uppercase text-neutral-900 border border-neutral-700 px-2 py-0.5">CARBINS</span>
          </div>
        </div>
      </div>

      {/* Modern sliding popup modal for full details */}
      {selectedService && (
        <div 
          onClick={() => setSelectedService(null)} 
          id="service_details_overlay"
          className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="bg-white border-2 border-black p-6 md:p-8 max-w-lg w-full relative rounded-lg shadow-2xl animate-scale-up"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-neutral-50 border border-black/10">
                {getServiceIcon(selectedService.id, "w-8 h-8 text-black")}
              </div>
              <button
                onClick={() => setSelectedService(null)}
                id="btn_close_modal"
                className="font-mono text-xs border border-black hover:bg-black hover:text-white px-2 py-1 transition-all cursor-pointer"
              >
                CLOSE [X]
              </button>
            </div>

            <h3 className="font-display text-xl md:text-2xl font-black uppercase text-black">
              {selectedService.title}
            </h3>
            
            <p className="font-sans text-xs md:text-sm text-black/80 font-light mt-3 leading-relaxed">
              {selectedService.fullDescription}
            </p>

            <div className="mt-5">
              <h4 className="font-mono text-[9px] text-black/50 tracking-widest uppercase mb-2">Key Advantages</h4>
              <ul className="space-y-1.5">
                {selectedService.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-center gap-2 text-xs text-black/80 font-sans">
                    <CheckCircle2 className="w-4 h-4 text-black shrink-0" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-5 pt-4 border-t border-black/10 flex flex-wrap justify-between items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-1 text-black/60">
                <Clock className="w-4 h-4 text-black" />
                <span>Estimate: {selectedService.approxTime}</span>
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {selectedService.brands.map((b, i) => (
                  <span key={i} className="px-2 py-0.5 border border-black/5 bg-neutral-50 text-[10px] font-mono text-black/70">
                    {b}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <a 
                href="#contact" 
                onClick={() => setSelectedService(null)} 
                className="w-full text-center block py-2.5 bg-black text-white hover:bg-neutral-800 text-[11px] font-mono tracking-wider uppercase border border-black transition-all font-bold"
              >
                Inquire Dehiwala Studio
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
