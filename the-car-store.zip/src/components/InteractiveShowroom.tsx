import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ToggleLeft, ToggleRight, Check, Hammer, Landmark, ShieldCheck, Sparkles, Volume2, Info, ArrowRight } from 'lucide-react';
import { ModificationState } from '../types';
import { carModelsData } from './ThreeDCarousel';

interface InteractiveShowroomProps {
  selectedCarId: string;
  onCarChange: (carId: string) => void;
}

export const InteractiveShowroom: React.FC<InteractiveShowroomProps> = ({ selectedCarId, onCarChange }) => {
  const currentCar = carModelsData.find(c => c.id === selectedCarId) || carModelsData[0];
  
  // Mod state
  const [mods, setMods] = useState<ModificationState>({
    modelId: selectedCarId,
    ppf: false,
    wrap: false,
    nanoCoating: false,
    bodykit: false,
    audio: false,
  });

  // Keep mods model in sync with selector changes
  useEffect(() => {
    setMods(p => ({
      ...p,
      modelId: selectedCarId
    }));
  }, [selectedCarId]);

  const toggleMod = (key: keyof Omit<ModificationState, 'modelId'>) => {
    setMods(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Compute estimate
  const baseCost = currentCar.customizerOptions.basePriceLKR;
  const ppfCost = mods.ppf ? currentCar.customizerOptions.ppfCostLKR : 0;
  const wrapCost = mods.wrap ? currentCar.customizerOptions.wrappingCostLKR : 0;
  const coatCost = mods.nanoCoating ? currentCar.customizerOptions.nanoCoatingCostLKR : 0;
  const kitCost = mods.bodykit ? currentCar.customizerOptions.bodykitCostLKR : 0;
  const audioCost = mods.audio ? currentCar.customizerOptions.audioCostLKR : 0;

  const totalCostLKR = baseCost + ppfCost + wrapCost + coatCost + kitCost + audioCost;

  // Formatting currency helper (Sri Lankan Rupees / LKR)
  const formatLKR = (num: number) => {
    return new Intl.NumberFormat('en-LK', {
      style: 'currency',
      currency: 'LKR',
      maximumFractionDigits: 0
    }).format(num);
  };

  // USD approximate lookup (mid range $)
  const formatUSD = (num: number) => {
    const usd = num / 300; // Approximate exchange rate
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(usd);
  };

  return (
    <div id="customizer" className="bg-neutral-50 text-black py-16 md:py-24 border-b border-black/10 relative">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-linear-gradient(to right, transparent, rgba(0,0,0,0.1), transparent)" />
      
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Module Header */}
        <div className="text-center mb-12 md:mb-16">
          <span className="text-[10px] font-mono tracking-widest text-black/50 uppercase block mb-1">
            LAB CLIENT STATION
          </span>
          <h2 className="font-display text-3xl md:text-5xl font-black text-black uppercase tracking-tight leading-none">
            SPECIFICATION ESTIMATOR
          </h2>
          <div className="h-[2px] w-20 bg-black mx-auto mt-3" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-start">
          
          {/* Main Visual Car Preview Column (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col items-center bg-white border border-black/10 p-6 md:p-8 rounded-lg relative overflow-hidden h-full min-h-[380px] md:min-h-[480px] justify-between">
            {/* Design Watermark */}
            <div className="absolute top-4 left-6 flex items-center gap-1.5 font-mono text-[9px] text-black/40">
              <span className="inline-block w-1.5 h-1.5 bg-black animate-pulse rounded-full" />
              SIMULATION PLATFORM v3.1
            </div>

            <div className="absolute top-4 right-6 font-mono text-[9px] text-black/40">
              VEHICLE CHASSIS OUTLINE
            </div>

            {/* Main morphing vehicle blueprint element */}
            <div className="relative w-full flex-1 flex items-center justify-center py-10 my-auto">
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] select-none pointer-events-none">
                <span className="font-display text-[110px] font-black tracking-tighter uppercase whitespace-nowrap">
                  {currentCar.id}
                </span>
              </div>

              {/* Laser Scanning Line for modification visualization */}
              {(mods.ppf || mods.wrap || mods.bodykit) && (
                <div className="absolute inset-x-8 top-1/2 h-[1px] bg-black/60 shadow-[0_0_10px_rgba(0,0,0,0.5)] z-20 animate-pulse pointer-events-none" />
              )}

              {/* Base image with dynamic filter based on customization. 
                  E.g., carbon wrap increases contrast/saturate, PPF makes it mirror gloss */}
              <motion.img
                key={currentCar.image}
                src={currentCar.image}
                alt={currentCar.name}
                referrerPolicy="no-referrer"
                className={`max-h-[180px] md:max-h-[290px] w-auto object-contain transition-all duration-500 ${
                  mods.wrap ? 'filter contrast-[1.25] brightness-[0.85]' : ''
                } ${
                  mods.ppf ? 'filter brightness-[1.03] drop-shadow-[0_8px_16px_rgba(0,0,0,0.1)]' : ''
                } ${
                  mods.nanoCoating ? 'filter saturate-[1.2] drop-shadow-[0_4px_10px_rgba(0,0,0,0.06)]' : ''
                }`}
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              />

              {/* Status overlay tags on corners */}
              <div className="absolute bottom-4 left-4 flex gap-1.5 flex-wrap">
                {mods.ppf && (
                  <span className="px-2 py-0.5 bg-black text-white text-[9px] font-mono rounded tracking-wider uppercase flex items-center gap-1">
                    <Check className="w-2.5 h-2.5" /> PPF Locked
                  </span>
                )}
                {mods.wrap && (
                  <span className="px-2 py-0.5 bg-black text-white text-[9px] font-mono rounded tracking-wider uppercase flex items-center gap-1">
                    <Check className="w-2.5 h-2.5" /> Stealth Wrap
                  </span>
                )}
                {mods.bodykit && (
                  <span className="px-2 py-0.5 bg-black text-white text-[9px] font-mono rounded tracking-wider uppercase flex items-center gap-1">
                    <Check className="w-2.5 h-2.5" /> Carbon Aero
                  </span>
                )}
              </div>
            </div>

            {/* Bottom active chassis indicators */}
            <div className="w-full border-t border-black/5 pt-4 flex flex-wrap justify-between gap-4 text-xs font-mono text-black/50">
              <div className="flex gap-4">
                <span>MODEL: {currentCar.name.toUpperCase()}</span>
                <span>STATE: {mods.wrap ? 'CUSTOM STATE' : 'DRAFT VIEW'}</span>
              </div>
              <div className="flex gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-black/80" />
                <span className={`w-2.5 h-2.5 rounded-full ${mods.ppf ? 'bg-black/80' : 'bg-black/10'}`} />
                <span className={`w-2.5 h-2.5 rounded-full ${mods.wrap ? 'bg-black/80' : 'bg-black/10'}`} />
                <span className={`w-2.5 h-2.5 rounded-full ${mods.bodykit ? 'bg-black/80' : 'bg-black/10'}`} />
              </div>
            </div>
          </div>

          {/* Configuration Modifications Side Control (lg:col-span-5) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Quick Car Picker Swapper */}
            <div className="bg-white border border-black/10 p-4 rounded-lg">
              <span className="text-[10px] font-mono tracking-widest text-black/40 uppercase block mb-3">
                Change Simulation Core
              </span>
              <div className="grid grid-cols-3 gap-2">
                {carModelsData.map(car => (
                  <button
                    key={car.id}
                    onClick={() => onCarChange(car.id)}
                    className={`py-2 px-1 text-center text-[10px] font-mono uppercase tracking-wider rounded transition-all border ${
                      selectedCarId === car.id 
                        ? 'bg-black text-white border-black font-semibold' 
                        : 'bg-neutral-50 text-black/60 border-black/5 hover:border-black/20'
                    }`}
                  >
                    {car.id === 'gtr' ? 'GT-R R35' : car.id === 'land_cruiser' ? 'Cruiser 300' : 'Defender'}
                  </button>
                ))}
              </div>
            </div>

            {/* Customizer Checklist Switches */}
            <div className="bg-white border border-black/10 p-5 rounded-lg flex flex-col gap-4">
              <span className="text-[10px] font-mono tracking-widest text-black/40 uppercase block border-b border-black/5 pb-2">
                SELECT UPGRADE MODULES
              </span>

              {/* PPF Option */}
              <div 
                onClick={() => toggleMod('ppf')}
                id="toggle_ppf"
                className="flex justify-between items-center bg-neutral-50/50 hover:bg-neutral-50 p-2.5 border border-black/5 rounded cursor-pointer transition-colors"
              >
                <div className="flex gap-2.5 items-start">
                  <ShieldCheck className="w-4 h-4 text-black/60 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-black font-display">Paint Protection Film (PPF)</h4>
                    <p className="text-[10px] text-black/50 font-sans font-light mt-0.5">Ultra premium self-healing polyurethane skin.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] font-medium text-black">
                    +{formatLKR(currentCar.customizerOptions.ppfCostLKR)}
                  </span>
                  {mods.ppf ? (
                    <ToggleRight className="w-6 h-6 text-black" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-black/30" />
                  )}
                </div>
              </div>

              {/* Custom wrapping */}
              <div 
                onClick={() => toggleMod('wrap')}
                id="toggle_wrap"
                className="flex justify-between items-center bg-neutral-50/50 hover:bg-neutral-50 p-2.5 border border-black/5 rounded cursor-pointer transition-colors"
              >
                <div className="flex gap-2.5 items-start">
                  <Hammer className="w-4 h-4 text-black/60 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-black font-display">Heat Rejection Ceramic Wrap</h4>
                    <p className="text-[10px] text-black/50 font-sans font-light mt-0.5">Matt, Chrome or Satin stealth aesthetics.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] font-medium text-black">
                    +{formatLKR(currentCar.customizerOptions.wrappingCostLKR)}
                  </span>
                  {mods.wrap ? (
                    <ToggleRight className="w-6 h-6 text-black" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-black/30" />
                  )}
                </div>
              </div>

              {/* Nano coating */}
              <div 
                onClick={() => toggleMod('nanoCoating')}
                id="toggle_coating"
                className="flex justify-between items-center bg-neutral-50/50 hover:bg-neutral-50 p-2.5 border border-black/5 rounded cursor-pointer transition-colors"
              >
                <div className="flex gap-2.5 items-start">
                  <Sparkles className="w-4 h-4 text-black/60 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-black font-display">Nano Ceramic Coating</h4>
                    <p className="text-[10px] text-black/50 font-sans font-light mt-0.5">Multi-staged chemical mirror gloss seal.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] font-medium text-black">
                    +{formatLKR(currentCar.customizerOptions.nanoCoatingCostLKR)}
                  </span>
                  {mods.nanoCoating ? (
                    <ToggleRight className="w-6 h-6 text-black" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-black/30" />
                  )}
                </div>
              </div>

              {/* Facelift Bodykit */}
              <div 
                onClick={() => toggleMod('bodykit')}
                id="toggle_bodykit"
                className="flex justify-between items-center bg-neutral-50/50 hover:bg-neutral-50 p-2.5 border border-black/5 rounded cursor-pointer transition-colors"
              >
                <div className="flex gap-2.5 items-start">
                  <Landmark className="w-4 h-4 text-black/60 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-black font-display">Carbon Facelift Bodykit</h4>
                    <p className="text-[10px] text-black/50 font-sans font-light mt-0.5">OEM bumper redesigns & carbon fibers.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] font-medium text-black">
                    +{formatLKR(currentCar.customizerOptions.bodykitCostLKR)}
                  </span>
                  {mods.bodykit ? (
                    <ToggleRight className="w-6 h-6 text-black" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-black/30" />
                  )}
                </div>
              </div>

              {/* Sound Custom Audio */}
              <div 
                onClick={() => toggleMod('audio')}
                id="toggle_audio"
                className="flex justify-between items-center bg-neutral-50/50 hover:bg-neutral-50 p-2.5 border border-black/5 rounded cursor-pointer transition-colors"
              >
                <div className="flex gap-2.5 items-start">
                  <Volume2 className="w-4 h-4 text-black/60 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-black font-display">Premium Acoustic Audio System</h4>
                    <p className="text-[10px] text-black/50 font-sans font-light mt-0.5">Flagship Pioneer/JBL sound stage layout.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] font-medium text-black">
                    +{formatLKR(currentCar.customizerOptions.audioCostLKR)}
                  </span>
                  {mods.audio ? (
                    <ToggleRight className="w-6 h-6 text-black" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-black/30" />
                  )}
                </div>
              </div>
            </div>

            {/* Output Pricing Estimator Box */}
            <div className="bg-black text-white p-5 rounded-lg flex flex-col justify-between border border-black shadow-xl">
              <div>
                <span className="text-[9px] font-mono tracking-widest text-white/40 uppercase block mb-1">
                  ESTIMATION REPORT
                </span>
                <span className="text-white/60 text-xs font-light block mb-4">
                  Includes base vehicle approximate local cost + premium additions.
                </span>

                <div className="border-t border-white/10 pt-3 flex justify-between items-baseline mb-1">
                  <span className="text-white/50 text-[10px] font-mono">TOTAL CHASSIS + WORKS:</span>
                  <span className="font-display text-lg md:text-2xl font-black text-white tracking-tight">
                    {formatLKR(totalCostLKR)}
                  </span>
                </div>

                <div className="flex justify-between items-baseline text-white/40 text-[10px] font-mono">
                  <span>EST. GLOBAL USD VAL:</span>
                  <span>~ {formatUSD(totalCostLKR)}</span>
                </div>
              </div>

              <div className="mt-6">
                <a 
                  href={`#contact?car=${currentCar.id}&mods=${[
                    mods.ppf ? 'ppf' : '',
                    mods.wrap ? 'wrap' : '',
                    mods.nanoCoating ? 'nano' : '',
                    mods.bodykit ? 'bodykit' : '',
                    mods.audio ? 'audio' : ''
                  ].filter(Boolean).join(',')}`}
                  id="btn_quote_request"
                  className="w-full text-center bg-white text-black hover:bg-neutral-100 py-3 text-[11px] font-mono tracking-widest uppercase flex items-center justify-center gap-2 font-black transition-all"
                >
                  Request Build Quote
                  <ArrowRight className="w-4 h-4" />
                </a>

                {/* Secure detailing disclaimer */}
                <div className="mt-3 flex gap-1.5 items-start text-[9px] text-white/30 font-sans leading-normal">
                  <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-white/40" />
                  <span>The Car Store operates as a high-end customized styling studio. Vehicle prices are market estimations and styling options are custom quoted.</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
