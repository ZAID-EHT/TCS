export interface CarModel {
  id: string;
  name: string;
  image: string;
  year: string;
  specs: {
    engine: string;
    power: string;
    transmission: string;
    drivetrain: string;
  };
  customizerOptions: {
    basePriceLKR: number;
    ppfCostLKR: number;
    wrappingCostLKR: number;
    nanoCoatingCostLKR: number;
    bodykitCostLKR: number;
    audioCostLKR: number;
  };
  description: string;
}

export interface ServiceDetail {
  id: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  benefits: string[];
  brands: string[];
  approxTime: string;
}

export interface ModificationState {
  modelId: string;
  ppf: boolean;
  wrap: boolean;
  nanoCoating: boolean;
  bodykit: boolean;
  audio: boolean;
}
