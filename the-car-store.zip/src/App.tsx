import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Instagram, 
  ChevronRight, 
  ShieldCheck, 
  Send, 
  CheckCircle,
  Cpu,
  BookmarkCheck,
  Zap,
  Gauge
} from 'lucide-react';
import { ServicesGrid } from './components/ServicesGrid';
import { ThreeScrollSystem } from './components/ThreeScrollSystem';

export default function App() {
  const selectedCarId = 'gtr';
  
  // Detailing Inquiry Form state
  const [inquiryForm, setInquiryForm] = useState({
    name: '',
    phone: '',
    vehicle: 'Nissan GT-R R35',
    service: 'Paint Protection Film (PPF)',
    details: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [activeFAQ, setActiveFAQ] = useState<number | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInquiryForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const submitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryForm.name || !inquiryForm.phone) {
      alert("Please enter both your Name and Contact Phone Number to schedule styling services.");
      return;
    }
    setIsSubmitted(true);
  };

  // FAQ list
  const faqs = [
    {
      question: "What is Paint Protection Film (PPF) and its benefits?",
      answer: "PPF is a specialized thick self-healing polyurethane skin applied to high-impact panels. It acts as an armor shield against Sri Lanka's road gravel, sandblasts, key gashes, and preserves original factory gloss perfectly."
    },
    {
      question: "How long does a Nano Quartz Ceramic Coating take?",
      answer: "A professional nano quartz coating takes approximately 2 days. This is because it demands deep rotary paint correction first to eradicate microscopic scratches, followed by hours of precise liquid chemical cure cycles."
    },
    {
      question: "Are your window tints secure and heat repelling?",
      answer: "Absolutely. We exclusively install multi-layered nano-ceramic heat rejection films. These reject up to 99% of infrared heat rays, keeping your cabin cool without blocking cellular, radio, or satellite navigation signals."
    },
    {
      question: "Where is The Car Store located in Sri Lanka?",
      answer: "We are situated in Dehiwala: 11, S De S. Jayasinghe Mawatha, Kalubowila, Dehiwala. We execute your styling projects in extreme dust-free sterile environments to warrant zero paint contamination."
    }
  ];

  return (
      <div className="min-h-screen bg-white text-black font-sans selection:bg-black selection:text-white relative overflow-x-hidden">
        
        {/* Floating Side Info Stripe (Sri Lankan standard styling) */}
        <div className="fixed left-4 bottom-4 z-40 hidden md:flex items-center gap-3 bg-white border border-black/15 py-2 px-3 hover:border-black/50 transition-colors shadow-xs">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neutral-900 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-black"></span>
        </span>
        <span className="text-[10px] font-mono tracking-wider text-black">
          ONLINE BOOKINGS • 077 839 4394
        </span>
      </div>

      {/* Top Navigation Header */}
      <header className="sticky top-0 bg-white/85 backdrop-blur-sm border-b border-black/5 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          
          {/* Logo Brand / Tilted Badge */}
          <a href="#" className="flex items-center gap-3 group">
            <div className="border-2 border-black px-2.5 py-1.5 font-display font-black text-xs uppercase tracking-widest text-white bg-black transform -skew-x-6 hover:-skew-x-0 transition-transform">
              TCS
            </div>
            <div className="flex flex-col">
              <span className="font-display text-sm font-black tracking-tight uppercase leading-none">THE CAR STORE</span>
              <span className="font-mono text-[8px] text-black/50 tracking-wider">one-stop perfection • dehiwala</span>
            </div>
          </a>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-6 text-[11px] font-mono tracking-wider uppercase">
            <a href="#showroom_deck" className="text-black/60 hover:text-black hover:underline transition-colors">Showroom</a>
            <a href="#services_section" className="text-black/60 hover:text-black hover:underline transition-colors">Services</a>
            <a href="#customizer" className="text-black/60 hover:text-black hover:underline transition-colors">Estimator</a>
            <a href="#faq_section" className="text-black/60 hover:text-black hover:underline transition-colors">FAQ</a>
            <a href="#contact" className="px-3.5 py-1.5 bg-black text-white hover:bg-neutral-800 transition-all font-semibold rounded">
              Book Appointment
            </a>
          </nav>

          {/* Quick contact trigger for mobile */}
          <div className="flex items-center gap-2 md:hidden">
            <a 
              href="tel:+94778394394" 
              className="px-3 py-1.5 border border-black text-xs font-mono tracking-wider uppercase hover:bg-black hover:text-white transition-all"
            >
              077 839 4394
            </a>
          </div>
        </div>
      </header>

      {/* Hero Visual Section Container */}
      <section className="relative min-h-[85vh] lg:min-h-[92vh] flex items-center bg-white border-b border-black/5 overflow-hidden px-6 lg:px-12 py-12">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center w-full relative z-10">
          
          {/* Hero Left Content Column (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            
            <div className="inline-flex items-center gap-1.5 px-3 py-1 border border-black/10 rounded-full text-[9px] font-mono tracking-widest uppercase text-black/60 mb-6 bg-white w-fit">
              <Cpu className="w-3 h-3 text-black animate-pulse" />
              Automotive Refinement Center Since 2024
            </div>

            <h1 className="font-display text-4xl sm:text-6xl lg:text-7xl font-black text-black leading-[0.9] tracking-tight uppercase">
              YOUR ONE-STOP SHOP<br />
              FOR CAR <span className="underline decoration-1 underline-offset-4">PERFECTION</span>!
            </h1>

            <p className="font-sans text-xs sm:text-sm text-black/60 font-light max-w-xl mt-6 leading-relaxed">
              We execute extreme-gloss liquid nano coatings, self-healing Paint Protection Film (PPF), ceramic sound insulation, heat rejection window tinting, and premium carbon facelift conversions in Kalubowila, Dehiwala.
            </p>

            {/* Quick specifications tag row */}
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 font-mono text-[10px] text-black">
              <div className="flex items-center gap-1 border-r border-black/10 pr-6">
                <ShieldCheck className="w-4 h-4 text-black" />
                <span>PPF / WRAP STYLE</span>
              </div>
              <div className="flex items-center gap-1 border-r border-black/10 pr-6">
                <Gauge className="w-4 h-4 text-black" />
                <span>HIGH REJECTION TINT</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap className="w-4 h-4 text-black" />
                <span>CARBON BODYKITS & AUDIO</span>
              </div>
            </div>

            {/* CTA buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
              <a 
                href="#showroom_deck"
                id="btn_hero_explore"
                className="px-6 py-3.5 bg-black text-white hover:bg-neutral-800 text-xs font-mono tracking-widest uppercase flex items-center justify-center gap-2 border border-black font-bold transition-all text-center"
              >
                Explore Vehicles
                <ChevronRight className="w-4 h-4" />
              </a>
              <a 
                href="#contact"
                id="btn_hero_contact"
                className="px-6 py-3.5 bg-white text-black hover:bg-neutral-50 text-xs font-mono tracking-widest uppercase flex items-center justify-center gap-2 border border-black transition-all text-center"
              >
                Studio Booking
              </a>
            </div>

            <div className="mt-12 flex items-center gap-4 text-xs font-mono text-black/50">
              <div className="flex flex-col">
                <span className="font-bold text-black text-sm">$$ MID-RANGE</span>
                <span>Prestige pricing without inflation</span>
              </div>
              <div className="h-8 w-[1px] bg-black/10" />
              <div className="flex flex-col">
                <span className="font-bold text-black text-sm">DEHIWALA</span>
                <span>Professional sterile bays</span>
              </div>
            </div>

          </div>

          {/* Hero Right Visual Column - Only shows subtle label on desktop as background Canvas draws the car */}
          <div className="lg:col-span-5 h-[300px] lg:h-full lg:min-h-[450px] flex items-center justify-center relative select-none pointer-events-none">
            <div className="absolute inset-0 flex flex-col justify-between p-6 border border-black/5 bg-neutral-50/5 lg:bg-transparent rounded-lg md:border-none">
              <div className="font-mono text-[9px] text-black/40 text-right leading-relaxed hidden lg:block">
                SCROLL TO NAVIGATE CHASSIS<br />
                INTERACTION SIMULATION ACTIVE
              </div>
              
              <div className="text-[11px] font-mono text-black/50 leading-relaxed max-w-xs self-end mt-auto hidden lg:block">
                *The 3D canvas is dynamically projected relative to your scrolling coordinates. Grab slider below or tilt mouse to revolve blueprint angles.
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3D GSAP Scroll-Based Runway Section */}
      <ThreeScrollSystem />

      {/* Services grid detailing PPF, coatings, tints, audio */}
      <ServicesGrid />

      {/* Trust & Local context FAQ section */}
      <section id="faq_section" className="bg-white text-black py-16 md:py-24 border-b border-black/10">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12 md:mb-16">
            <span className="text-[10px] font-mono tracking-widest text-black/50 uppercase block mb-1">STYLING INTEL</span>
            <h2 className="font-display text-3xl md:text-5xl font-black uppercase text-black">COMMON QUERIES</h2>
            <div className="h-[2px] w-12 bg-black mx-auto mt-3" />
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = activeFAQ === index;
              return (
                <div 
                  key={index} 
                  className="border border-black/10 rounded-lg overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setActiveFAQ(isOpen ? null : index)}
                    className="w-full text-left p-5 flex justify-between items-center bg-neutral-50 hover:bg-neutral-100 transition-colors"
                  >
                    <span className="font-display text-sm md:text-base font-bold uppercase text-black tracking-tight">
                      {faq.question}
                    </span>
                    <span className="font-mono text-xs font-black">
                      {isOpen ? '[-]' : '[+]'}
                    </span>
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="bg-white"
                      >
                        <p className="p-5 font-sans text-xs md:text-sm text-black/70 leading-relaxed border-t border-black/5 font-light">
                          {faq.answer}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Dynamic contact and secure booking form block */}
      <section id="contact" className="bg-white text-black py-16 md:py-24 relative">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 md:gap-16 items-start">
          
          {/* Left contact info Column (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-8 lg:sticky lg:top-28">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-black/50 uppercase block mb-1">STUDIO RESIDENCY</span>
              <h2 className="font-display text-3xl md:text-5xl font-black uppercase tracking-tight text-black leading-none">
                THE CAR STORE
              </h2>
              <p className="font-sans text-xs md:text-sm text-black/60 font-light mt-3 leading-relaxed">
                Connect with Dehiwala’s premium vehicle modifiers. Grab an appointment with our elite detailing crew to secure high-contrast wrap conversions.
              </p>
            </div>

            {/* Core Info Details parsed right from the script */}
            <div className="space-y-4 font-sans text-xs md:text-sm">
              
              <div className="flex gap-4 items-start p-4 border border-black/5 hover:border-black/20 rounded bg-neutral-50/30 transition-all">
                <MapPin className="w-5 h-5 text-black mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-mono text-[9px] text-black/50 tracking-widest uppercase mb-1">PHYSICAL STUDIO</h4>
                  <p className="font-display text-black font-bold">
                    11, S De S. Jayasinghe Mawatha,<br />
                    Kalubowila, Dehiwala, Sri Lanka.
                  </p>
                  <span className="text-[10px] text-black/60 mt-1 block">Opposite Kalubowila hospital zone. Dust-locked, sterile styling bays.</span>
                </div>
              </div>

              <div className="flex gap-4 items-start p-4 border border-black/5 hover:border-black/20 rounded bg-neutral-50/30 transition-all">
                <Phone className="w-5 h-5 text-black mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-mono text-[9px] text-black/50 tracking-widest uppercase mb-1">HOTLINE DECK</h4>
                  <p className="font-mono text-black font-black text-sm md:text-base">
                    +94 77 839 4394
                  </p>
                  <span className="text-[10px] text-black/60 mt-1 block">Cell / WhatsApp inquiries. Operating hours: 9:00 AM – 7:00 PM.</span>
                </div>
              </div>

              <div className="flex gap-4 items-start p-4 border border-black/5 hover:border-black/20 rounded bg-neutral-50/30 transition-all">
                <Mail className="w-5 h-5 text-black mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-mono text-[9px] text-black/50 tracking-widest uppercase mb-1">DIRECT MAIL</h4>
                  <p className="font-mono text-black font-semibold">
                    thecarstore77@gmail.com
                  </p>
                  <p className="font-mono text-black/40 text-[10px] mt-0.5">thecarstore.lk</p>
                </div>
              </div>

            </div>

            {/* High fidelity social media cards */}
            <div>
              <h4 className="font-mono text-[9px] text-black/50 tracking-widest uppercase mb-4 text-center lg:text-left">
                VISIT THE CAR STORE SOCIAL STREAM
              </h4>
              <div className="flex items-center justify-center lg:justify-start gap-4">
                <a 
                  href="https://facebook.com/thecarstore.lk" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  id="link_facebook"
                  className="flex items-center gap-2 p-3 border border-black/10 rounded hover:border-black hover:bg-neutral-50 transition-all text-xs font-mono"
                >
                  <Facebook className="w-4 h-4 text-black" />
                  <span>Facebook</span>
                </a>
                
                <a 
                  href="https://instagram.com/thecarstore.lk" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  id="link_instagram"
                  className="flex items-center gap-2 p-3 border border-black/10 rounded hover:border-black hover:bg-neutral-50 transition-all text-xs font-mono"
                >
                  <Instagram className="w-4 h-4 text-black" />
                  <span>Instagram</span>
                </a>
                
                <a 
                  href="https://tiktok.com/@thecarstore.lk" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  id="link_tiktok"
                  className="flex items-center gap-2 p-3 border border-black/10 rounded hover:border-black hover:bg-neutral-50 transition-all text-xs font-mono"
                >
                  <span className="font-black text-[13px] text-black italic">T</span>
                  <span>TikTok</span>
                </a>
              </div>
            </div>

          </div>

          {/* Right inquiry form Column (lg:col-span-7) */}
          <div className="lg:col-span-7 bg-neutral-50/50 border border-black/10 p-6 md:p-8 rounded-lg relative overflow-hidden">
            
            <div className="absolute top-0 left-0 w-2 h-full bg-black" />

            <div className="mb-6">
              <h3 className="font-display text-xl md:text-2xl font-black uppercase text-black flex items-center gap-2">
                <BookmarkCheck className="w-6 h-6 text-black" />
                SECURE DETAILED INQUIRY
              </h3>
              <p className="font-sans text-xs text-black/50 mt-1 font-light">
                Configure your service parameters below and lock in a premium detailing diagnostic appointment.
              </p>
            </div>

            {isSubmitted ? (
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                id="booking_success_message"
                className="bg-white border border-black p-8 text-center space-y-4 rounded"
              >
                <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-2 shadow-md">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h4 className="font-display text-lg font-bold uppercase tracking-tight text-black">Inquiry Locked Successfully!</h4>
                <div className="font-mono text-xs text-black/70 space-y-1 block max-w-sm mx-auto text-left py-3 border-y border-black/5 my-4">
                  <p><strong>CLIENT NAME:</strong> {inquiryForm.name}</p>
                  <p><strong>TELEPHONE:</strong> {inquiryForm.phone}</p>
                  <p><strong>CHASSIS CORE:</strong> {inquiryForm.vehicle}</p>
                  <p><strong>SERVICE:</strong> {inquiryForm.service}</p>
                </div>
                <p className="font-sans text-xs text-black/60 font-light leading-relaxed">
                  Thank you for booking with **The Car Store**. Our master detailing engineer from our Kalubowila workshop will respond to your telephone number (+94 / {inquiryForm.phone}) within the next 2-4 business hours with custom slot openings.
                </p>
                <button
                  onClick={() => setIsSubmitted(false)}
                  id="btn_book_another"
                  className="px-5 py-2.5 bg-black text-white hover:bg-neutral-800 text-[10px] font-mono uppercase tracking-widest"
                >
                  Submit New Booking
                </button>
              </motion.div>
            ) : (
              <form onSubmit={submitInquiry} className="space-y-4">
                
                {/* Client Name input */}
                <div>
                  <label htmlFor="input_name" className="font-mono text-[9px] text-black/60 tracking-widest uppercase block mb-2 font-bold">
                    1. CLIENT NAME *
                  </label>
                  <input
                    type="text"
                    id="input_name"
                    name="name"
                    value={inquiryForm.name}
                    onChange={handleInputChange}
                    placeholder="Enter your name"
                    className="w-full bg-white border border-black/20 px-3 py-2.5 text-xs text-black placeholder-black/30 rounded focus:border-black outline-none font-sans"
                    required
                  />
                </div>

                {/* Contact Phone Number */}
                <div>
                  <label htmlFor="input_phone" className="font-mono text-[9px] text-black/60 tracking-widest uppercase block mb-2 font-bold">
                    2. TELEPHONE NUMBER (SRI LANKA) *
                  </label>
                  <input
                    type="tel"
                    id="input_phone"
                    name="phone"
                    value={inquiryForm.phone}
                    onChange={handleInputChange}
                    placeholder="e.g., 077 839 4394 / +94..."
                    className="w-full bg-white border border-black/20 px-3 py-2.5 text-xs text-black placeholder-black/30 rounded focus:border-black outline-none font-mono"
                    required
                  />
                </div>

                {/* Car selector drop list */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="input_vehicle" className="font-mono text-[9px] text-black/60 tracking-widest uppercase block mb-2">
                      3. CHASSIS MODEL SELECT
                    </label>
                    <select
                      id="input_vehicle"
                      name="vehicle"
                      value={inquiryForm.vehicle}
                      onChange={handleInputChange}
                      className="w-full bg-white border border-black/20 px-3 py-2.5 text-xs text-black rounded focus:border-black outline-none font-sans"
                    >
                      <option value="Nissan GT-R R35">Nissan GT-R R35</option>
                      <option value="Toyota Land Cruiser 300">Toyota Land Cruiser 300</option>
                      <option value="Land Rover Defender 110">Land Rover Defender 110</option>
                      <option value="Other Premium Vehicle">Other Specialist Vehicle</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="input_service" className="font-mono text-[9px] text-black/60 tracking-widest uppercase block mb-2">
                      4. TARGET OPERATION
                    </label>
                    <select
                      id="input_service"
                      name="service"
                      value={inquiryForm.service}
                      onChange={handleInputChange}
                      className="w-full bg-white border border-black/20 px-3 py-2.5 text-xs text-black rounded focus:border-black outline-none font-sans"
                    >
                      <option value="Paint Protection Film (PPF)">Paint Protection Film (PPF)</option>
                      <option value="Nano Ceramic Coating">Nano Ceramic Coating</option>
                      <option value="Heat Rejection Window Tint">Heat Rejection Window Tint</option>
                      <option value="Carbon Fiber Upgrades">Carbon Fiber & Facelift bodykits</option>
                      <option value="Precision Detailing">Premium Detailing Wash & Wax</option>
                      <option value="High-End Audio">High-End Audio Install</option>
                    </select>
                  </div>
                </div>

                {/* Dynamic details comments box */}
                <div>
                  <label htmlFor="input_details" className="font-mono text-[9px] text-black/60 tracking-widest uppercase block mb-2">
                    5. DESIGN REQUEST / CUSTOM DETAILS (OPTIONAL)
                  </label>
                  <textarea
                    id="input_details"
                    name="details"
                    value={inquiryForm.details}
                    onChange={handleInputChange}
                    placeholder="Describe specific details, e.g. Satin black custom wrap, 3M ceramic tint darkness level, component speakers integration, etc."
                    className="w-full bg-white border border-black/20 p-3 text-xs text-black placeholder-black/30 rounded focus:border-black outline-none h-24 font-sans resize-none"
                  />
                </div>

                {/* Send Button */}
                <button
                  type="submit"
                  id="btn_submit_booking"
                  className="w-full py-3.5 bg-black text-white hover:bg-neutral-800 text-xs font-mono tracking-widest uppercase flex items-center justify-center gap-2 border border-black font-semibold transition-all cursor-pointer rounded"
                >
                  <Send className="w-3.5 h-3.5" />
                  SUBMIT SECURE SESSION RESERVATION
                </button>

                <p className="text-[9px] text-black/40 text-center leading-normal">
                  *By submitting, you authorize The Car Store styling team to contact you via Whatsapp or phone call +94 77 839 4394 to finalize slot schedules.
                </p>

              </form>
            )}

          </div>

        </div>
      </section>

      {/* High-contrast Black Footer layout */}
      <footer className="bg-black text-white py-16 px-6 border-t border-black/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-12 border-b border-white/10 pb-12">
          
          <div className="space-y-4">
            <div className="flex items-center gap-2 font-display text-xl font-black uppercase tracking-widest text-white">
              <span className="border-2 border-white px-2 py-0.5 mr-1 font-black bg-white text-black">TCS</span>
              THE CAR STORE
            </div>
            <p className="font-sans text-xs text-white/50 font-light max-w-sm leading-relaxed">
              Based in Kalubowila, Dehiwala. We are Sri Lanka’s premier black-and-white detailing laboratory crafting vehicle perfection through surgical nano quartz coating and polyurethane clear skins.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-8">
            <div className="space-y-2">
              <h5 className="font-mono text-[9px] text-white/40 tracking-widest uppercase">NAVIGATIONAL</h5>
              <ul className="text-xs space-y-1 text-white/60 font-light">
                <li><a href="#showroom_deck" className="hover:text-white">Active Showroom</a></li>
                <li><a href="#services_section" className="hover:text-white">Our Services</a></li>
                <li><a href="#customizer" className="hover:text-white">Price Estimator</a></li>
                <li><a href="#faq_section" className="hover:text-white">Common FAQs</a></li>
              </ul>
            </div>

            <div className="space-y-2">
              <h5 className="font-mono text-[9px] text-white/40 tracking-widest uppercase">STYLING UNITS</h5>
              <ul className="text-xs space-y-1 text-white/60 font-light text-nowrap">
                <li><span>Paint Protection (PPF)</span></li>
                <li><span>Nano Glasses Coating</span></li>
                <li><span>Facial Conversions</span></li>
                <li><span>Sound Insulation</span></li>
              </ul>
            </div>

            <div className="space-y-2 col-span-2 sm:col-span-1">
              <h5 className="font-mono text-[9px] text-white/40 tracking-widest uppercase">HOTLINE</h5>
              <p className="font-mono text-sm font-black whitespace-nowrap text-white">
                077 839 4394
              </p>
              <span className="text-[10px] text-white/40 block">Dehiwala, Sri Lanka</span>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto pt-8 flex flex-col sm:flex-row justify-between items-center text-white/40 font-mono text-[9px] tracking-wider gap-4">
          <div className="flex gap-4">
            <span>© 2026 THE CAR STORE. ALL RIGHTS RESERVED.</span>
            <span className="hidden sm:inline">•</span>
            <span>DEHIWALA STYLES LAB</span>
          </div>
          <div>
            <span>PROUDLY MADE IN SRI LANKA • THECARSTORE.LK</span>
          </div>
        </div>

      </footer>

    </div>
  );
}
