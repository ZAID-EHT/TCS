import React, { useRef, useLayoutEffect, Component, ReactNode } from "react";
import { Canvas } from "@react-three/fiber";
import { useGLTF, Environment, ContactShadows } from "@react-three/drei";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import * as THREE from "three";

gsap.registerPlugin(ScrollTrigger);

class ModelErrorBoundary extends Component<{children: ReactNode}, {hasError: boolean}> {
  constructor(props: {children: ReactNode}) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error: Error) {
    console.error("3D Model failed to load:", error);
    return { hasError: true };
  }
  render() {
    if (this.state.hasError) {
      return (
        <mesh>
          <boxGeometry args={[1.5, 1, 3]} />
          <meshStandardMaterial color="#bc000c" />
        </mesh>
      );
    }
    return this.props.children;
  }
}

function CarModel() {
  // To use your Nissan GTR model:
  // 1. Upload your .glb file to the "public" folder using the file explorer (create the folder if it doesn't exist)
  // 2. Change the string below to "/your_file_name.glb" (e.g., "/nissan_gtr.glb")
  const { scene } = useGLTF("https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/porsche-911/model.gltf");
  return <primitive object={scene} />;
}

export function Showcase3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const carWrapperRef = useRef<THREE.Group>(null);
  const maskRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLHeadingElement>(null);
  
  const tooltip1Ref = useRef<HTMLDivElement>(null);
  const tooltip2Ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!containerRef.current || !sectionRef.current || !maskRef.current) return;

    let ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=3000", 
          pin: true,
          scrub: 1,
        }
      });

      // 1. Circular Reveal
      tl.to(maskRef.current, {
        clipPath: "circle(150% at 50% 50%)",
        duration: 2,
        ease: "power2.inOut"
      }, 0);

      // 2. Rotate Car Model wrapper (always mounted)
      if (carWrapperRef.current) {
        tl.to(carWrapperRef.current.rotation, {
          y: Math.PI * 2,
          ease: "none",
          duration: 4
        }, 0);
      }

      // 3. Header parallax fade
      tl.to(headerRef.current, {
        opacity: 0,
        y: -100,
        duration: 1
      }, 1);

      // 4. Reveal tooltips staggered
      tl.fromTo([tooltip1Ref.current, tooltip2Ref.current], {
        opacity: 0,
        scale: 0.8,
        y: 20
      }, {
        opacity: 1,
        scale: 1,
        y: 0,
        duration: 1,
        stagger: 0.5
      }, 1.5);

      // Hide tooltips before the end
      tl.to([tooltip1Ref.current, tooltip2Ref.current], {
        opacity: 0,
        y: -20,
        duration: 0.5
      }, 3.5);

    }, containerRef);
    
    return () => ctx.revert();
  }, []);

  return (
    <div ref={containerRef} className="relative z-20">
      <div 
        ref={sectionRef} 
        className="h-screen w-full relative bg-primary flex items-center justify-center overflow-hidden overflow-y-hidden"
      >
        <h2 className="font-headline text-5xl md:text-8xl text-on-primary uppercase text-center absolute z-0 tracking-tight">
          Precision <br/> Engineering
        </h2>

        {/* Circular Reveal Container */}
        <div 
          ref={maskRef} 
          className="absolute inset-0 bg-surface-lowest z-10 overflow-hidden" 
          style={{ clipPath: "circle(0% at 50% 50%)" }}
        >
          {/* 3D Canvas */}
          <Canvas camera={{ position: [0, 1.5, 6], fov: 45 }} gl={{ antialias: true }} dpr={[1, 2]}>
            <ambientLight intensity={0.5} />
            <directionalLight position={[10, 10, 5]} intensity={1.5} />
            <directionalLight position={[-10, 10, -5]} intensity={0.5} />
            
            <ModelErrorBoundary>
              <Environment preset="city" />
            </ModelErrorBoundary>

            <group ref={carWrapperRef} position={[0, -0.8, 0]}>
              <ModelErrorBoundary>
                <React.Suspense fallback={null}>
                  <CarModel />
                </React.Suspense>
              </ModelErrorBoundary>
            </group>
            
            <ContactShadows resolution={512} scale={10} blur={2} opacity={0.5} far={4} position={[0, -0.8, 0]} />
          </Canvas>
          
          {/* HTML Overlays over Canvas */}
          <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between py-24 px-gutter md:px-24">
             <div className="flex justify-center w-full">
                <h2 ref={headerRef} className="font-headline text-5xl md:text-7xl uppercase text-primary tracking-tight">
                  The GTR Experience
                </h2>
             </div>
             
             {/* Tooltips */}
             <div className="w-full h-full relative font-mono uppercase tracking-widest text-xs flex items-center justify-between pointer-events-none hidden md:flex">
                <div ref={tooltip1Ref} className="bg-primary/90 text-on-primary p-4 border-l-4 border-secondary translate-x-12 translate-y-24">
                  <p className="font-bold mb-1">Ceramic Shield</p>
                  <p className="opacity-80">9H Hardness Protection</p>
                </div>
                
                <div ref={tooltip2Ref} className="bg-primary/90 text-on-primary p-4 border-l-4 border-secondary -translate-x-12 -translate-y-24">
                  <p className="font-bold mb-1">Flawless Finish</p>
                  <p className="opacity-80">100% Swirl Correction</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Also update this path if you change the model URL above
useGLTF.preload("https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/porsche-911/model.gltf");
